<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'PostFinance Checkout Integration for Commerce on MODX
=

https://checkout.postfinance.ch/en-us/doc

_"PostFinance Checkout is the most practical all-in-one payment solution for Swiss online shops – a contractual partner, a plug-in and five payment options for your customers: PostFinance Card, PostFinance e-finance, TWINT, Visa and Mastercard."_

Requirements
-

Commerce_PFCheckout requires at least MODX 2.6.5 and PHP 7.1 or higher. Commerce by modmore should be at least version 1.1.4. You also need to have an PostFinance Checkout account which provides the `space id`, `user id` and `secret key`.

Installation
-

Install via the MODX package manager. The listing name is "PostFinance Checkout for Commerce". The package namespace is Commerce_PFCheckout.

Setup the Module
-

Once installed, navigate to Commerce in the MODX manager. Select the Configuration tab and then click on Modules. Find Commerce_PFCheckout in the module list and click on it to make a window pop up where you can enable the module for Test Mode, Live Mode, or both.

Now the module is enabled, you can click on the Payment Methods tab on the left. Then click Add a Payment Method. Select PostFinance Checkout from the Gateway dropdown box and then give it a name e.g. PostFinance Checkout. Next, click on the availability tab and enable it for test or live modes and then click save.

After saving, you\'ll see an extra PostFinance Checkout tab appears at the top of the window. Here you can enter your PostFinance Checkout API credentials: `Space id`, `User id` and the `Secret key`

Congratulations! PostFinance Checkout should now appear as a payment method a customer can use during checkout.

Customize the Markup
-

On the payment page of the checkout process in Commerce, the PostFinance Checkout payment method is
displayed according to a default twig template located in your MODX install at:
```core/components/commerce_pfcheckout/templates/frontend/gateways/postfinancegateway.twig```

There is a system setting in the commerce_pfcheckout namespace called `commerce_pfcheckout.payment_template`.
The default value is ```frontend/gateways/postfinancegateway.twig```

If you would like to customise the default template, don\'t edit the file directly as it will
be overwritten in future upgrades. Instead, create a new file in the same location with a different name
e.g. `mycustomtemplate.twig` and update the system setting\'s value.

For example: ```frontend/gateways/mycustomtemplate.twig```. The module will then use your custom template
automatically.

Setup in the PostFinance Checkout Portal
-

Besides the template, most configuration takes place inside PostFinance Checkout\'s merchant portal.
You need to setup your which payment methods you want to accept, and you can customise the look
of the payment page the customer is redirected to.

You will also need to get your three authentication details here:
1. Space id
2. User id
3. Secret Key

Login here: https://checkout.postfinance.ch/user/login

Testing
=

https://developer.postfinancepayments.ch/documentation/testcases/',
    'changelog' => 'PFCheckout for Commerce 1.0.1-pl
---------------------------------
Released on 30/03/2021

- Removed requirement for template system setting. Commerce gives preference to theme templates over module templates so it isn\'t needed.
- Added optional logging to transaction->log()

PFCheckout for Commerce 1.0.0-pl
---------------------------------
Released on 30/03/2021

- First pl release

PFCheckout for Commerce 1.0.0-beta2
---------------------------------
Released on 30/01/2021

- Fixed a bug when calculating orderItem total pricing. Use $orderItem rather than $order.

PFCheckout for Commerce 1.0.0-beta1
---------------------------------
Released on 29/01/2021

- First beta release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'aa8cd64fe0a2a582be35fe7e1144c147',
      'native_key' => 'commerce_pfcheckout',
      'filename' => 'modNamespace/b6889798557a092c5a085fc7c9bd3cbc.vehicle',
      'namespace' => 'commerce_pfcheckout',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a853baac2e3f91666b7a04ad1cbed491',
      'native_key' => 'a853baac2e3f91666b7a04ad1cbed491',
      'filename' => 'xPDOFileVehicle/ecbc849c93ba116ac1a25effecbb4d48.vehicle',
    ),
  ),
);