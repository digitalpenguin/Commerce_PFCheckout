<?php

$_lang['commerce_pfcheckout'] = 'PostFinance Checkout';
$_lang['commerce_pfcheckout.description'] = 'A short description of what PostFinance Checkout does.';

$_lang['commerce_pfcheckout.gateway'] = 'PostFinance Checkout';
$_lang['commerce_pfcheckout.postfinance_checkout_payment_methods'] = 'PostFinance Checkout Payment Methods';
